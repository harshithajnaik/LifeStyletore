
<html>
    <head>
        <title>Setting</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href ="bootstrap/css/bootstrap.min.css" rel = "stylesheet" type ="text/css">
        <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src= "bootstrap/js/jquery-3.2.1.min.js"></script>
        <link href ="css_assi2.css" type="text/css" rel="stylesheet">
    </head>
    <body>
     
             <div class =" navbar navbar-inverse navbar-fixed-top">
           
                <div class ="navbar-header ">
                    <button type="button" class = "navbar-toggle" data-toggle = "collapse" data-target = "#mynav">
                        <span class=" icon-bar"></span>
                         <span class=" icon-bar"></span>
                          <span class=" icon-bar"></span>
                        
                    </button>
                    <div class =" navbar-brand">Lifestyle Store
                </div>
                </div>
                <div class="collapse navbar-collapse" id ="mynav">
                   <ul class="nav navbar-nav navbar-right">
                       <li><a href = "cart.html"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li>
                          <li><a href = "setting.html"><span class="glyphicon glyphicon-user"></span> Settings</a></li>
                            <li><a href = "logout.html"><span class="glyphicon glyphicon-log-out"></span> Log Out </a></li>
                    </ul>
                </div>
           </div>
        <div>
            <div class="row">
                <div class="col-md-4 col-md-offset-4">
                    <form class="form-group">
                        <br><br>
                        
                        <H1>Change Password</h1><br>
                        
                        <input class="form-control" type="text" placeholder="Old Password"><br>
                         <input class="form-control" type="text" placeholder="New Password"><br>
                         <input class="form-control" type="text" placeholder="Re-type Password"><br>
                         <button class="btn btn-primary">Change</button>
                    </form>
                </div>
        </div>
        </div>
        <div class="row">
         
        <footer style="margin-top:10%">
            <div class = "container">
                <center>
                    <p> Copyright © Lifestyle Store. All Rights
                        Reserved􀆉 and 􀆈Contact Us: +91 90000 00000</p>
                </center>
             </div>
        </footer>
        </div>
    </body>
</html>
