<?php

 function check_if_added_to_cart($item_id){
     include 'common.php';
     if(!isset($_SESSION))
     	session_start();
     $user_id=$_SESSION['id'];
     $stat  = "SELECT * FROM user_items WHERE item_id='$item_id' AND user_id ='$user_id' AND status='Added to cart'";
    $query=mysqli_query($con,$stat);
    $n = mysqli_num_rows($query);
    if($n >=1 ){
        return 1;
        }
    else {
    return 0;    
    }
     
 }
?>
