<?php
include 'common.php';
$email = mysqli_real_escape_string($con,$_POST('email'));
$pwd = md5($_POST('password'));
$query = "select id , email from users where id ='$email' and password = '$pwd";
$quer_ans = mysqli_query($con, $query);
$count = mysqli_num_rows($quer_ans);
if($count == 0){
    echo "<center><h4>There is no such user </h4></center>";
}
else{
    $_SESSION['email'] = $email;
    $_SESSION['password'] = $pwd;
    header('../products_php');
}
?>