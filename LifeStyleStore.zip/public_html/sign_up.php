
<?php


include 'includes/common.php';

if(isset($SESSION['email'])){
    header ('location : products_page.php');
}

?>
<html>
    <head>
        <title>Sign Up </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href ="bootstrap/css/bootstrap.min.css" rel = "stylesheet" type ="text/css">
        <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src= "bootstrap/js/jquery-3.2.1.min.js"></script>
        <link href ="css_assi2.css" type="text/css" rel="stylesheet">
    </head>
    <body>
       <?php include 'includes/header.php';
       ?>
        
                <div class="col-sm-4 col-sm-offset-4">
            <div class="panel panel-primary ">
               <div class="panel-heading"> <h1>SIGN UP</h1></div>
          
            <div class=" panel-body">
                <form class="form-group" method="post" action ="signup_script.php">
        <input class = "form-control" type="text" placeholder="Name" name = "name"> <br>
        <div class="form-group"> <input class = "form-control" type="email" placeholder="Email" name = "email"> <br></div>
        <div class="form-group"><input class = "form-control" type="password" placeholder="Password" name ="password" pattern = "{6,}"><br> </div>
        <div class="form-group"><input class = "form-control" type="number" placeholder="Phone number" name ="contact"><br> </div>
        <div class="form-group"><input class = "form-control" type="text" placeholder="city" name = "city"> <br></div>
   <div class="form-group"><input class = "form-control" type="text" placeholder="Address" name="address"> <br><div>
                    <input class ="btn btn-primary" type  ="submit">
            </div>
            </div>
                </form>
        </div>
            </div>
        </div>
      
         <?php include 'includes/footer.php';?>
    
  
     
    </body>
</html>
