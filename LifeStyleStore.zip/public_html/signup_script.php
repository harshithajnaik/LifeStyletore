<?php

include 'includes/common.php';
$email1 = $_POST['email'];
$regexp = " [a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$";
/**if(!preg_match($regexp, $email1)){
    echo "<center><h4>Incorrect email.</h4></center>";
}*/
$pass = $_POST['password'];
if($pass <6){
    echo  "Password should have at least 6 characters";
}
$quer = "select id from users where email = '$email1'";
$r = mysqli_query($con,$quer);
$re = mysqli_num_rows($r);
if($re > 0){
    echo "Email ID already exists!!";
}
else{
$name = $_POST['name'];
$em = $_POST['email'];
$password = $_POST['password'];
$contact= $_POST['contact'];
$city =$_POST['city'];
$address=$_POST['address'];
$q = "insert into users(name, email,password, contact,city, address) values ('$name' , '$em' , '$password','$contact','$city','$address')";
$que_ans = mysqli_query($con , $q) or die (mysqli_error($con));
$_SESSION['id'] = mysqli_insert_id($con);
 $_SESSION['email'] = $em;
    $_SESSION['password'] = $password;
    header('location:products_page');
}
?>

