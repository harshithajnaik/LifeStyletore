
<html>
    <head>
        <title>success</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href ="bootstrap/css/bootstrap.min.css" rel = "stylesheet" type ="text/css">
        <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src= "bootstrap/js/jquery-3.2.1.min.js"></script>
        <link href ="css_assi2.css" type="text/css" rel="stylesheet">
    </head>
    <body>
        <div>
            <div style="margin-top: 15% ; margin-bottom: 10%">
                <center><br><br>
                <h2>Your order is confirmed. Thank you for shopping
                    with us.<a href="product.html">Click</a> here to purchase any other item.</h2></center>
            </div>
        </div>
        <footer>
            <div class = "container">
                <center>
                    <p> Copyright © Lifestyle Store. All Rights
                        Reserved􀆉 and 􀆈Contact Us: +91 90000 00000</p>
                </center>
             </div>
        </footer>
    </body>
</html>
