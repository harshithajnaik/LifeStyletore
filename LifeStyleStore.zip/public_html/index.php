<?php
 require 'includes/common.php';
 if (isset($_SESSION['email'])) {
header('location: products_page.php');
}?>

<html>
    <head>
        <title>Life Style Store</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href ="bootstrap/css/bootstrap.min.css" rel = "stylesheet" type ="text/css">
        <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src= "bootstrap/js/jquery-3.2.1.min.js"></script>
        <link href ="css_assi2.css" type="text/css" rel="stylesheet">
     </head>
    <body>
        <?php
        include 'includes/header.php';
        ?>
        <div id ="banner_img">
          <div class="container">
               <div id ="banner_content">
                   <a  class ="btn btn-danger btn-lg active" href="product.html">Shop Now</a>
                </div>
           </div>
        </div>
       <?php
       include 'includes/footer.php';
       ?>
            
     </body>
</html>
