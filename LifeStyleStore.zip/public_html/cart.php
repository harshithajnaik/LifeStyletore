<?php
include 'includes/common.php';
session_start();
if(!isset($_SESSION['id'])){
   header('location:login.php');
}
$id_user = $_SESSION['id'];
$all_item = "SELECT i.item_id , p.name, p.price
FROM users_items p , items  i 
where user_items.user_id = $id_user";
$resul = mysqli_query($con, $all_item);
$no= mysqli_num_rows($resul);
if($no == 0){
    echo "<h4> Add items to the cart first! </h4>";
    header('location:products_page.php');
 }
 else{
    while($cost = mysqli_fetch_array($resul)){
        $sum = 0;
        $sum = $sum + $cost['price'];
        echo "Item number  :" . $cost['id'] "\n". <a href='cart-remove.php?id={$cost['id']}'
class='remove_item_link'> Remove</a>"Item Name:"."$cost['name']";
 }
 echo = "total :".$sum;
 header('location:includes/header.php?id = $id_user,id_item = ');
}

?>
<html>
    <head>
        <title>Cart Page</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
         <link href ="bootstrap/css/bootstrap.min.css" rel = "stylesheet" type ="text/css">
        <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src= "bootstrap/js/jquery-3.2.1.min.js"></script>
        <link href ="css_assi2.css" type="text/css" rel="stylesheet">
    </head>
    <body>
       
        <div>
            <?php
            include 'includes/header.php';
            ?>
         
        </div>
        <div class="row">
        <div class="col-md-offset-2">
        <table class="table table-striped ">
            <br><br>
            <br><br>
         
               <thead>
                        <tr>
                            <th>Item Number</th>
                            <th>Item Name</th>
                            <th>Price</th>
                            <th></th>
                        </tr>
                </thead>
                <tbody>
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                     </tr>
                     <tr>
                         <td></td>
                         <td>Total</td>
                         <td>Rs.0</td>
                         <td><a href="success.html"><button class="btn btn-primary"> Confirm Order </button></a></td>
                     </tr>
        </table>
            </div>
        </div>
        <div class="row">
         <?php
                     include 'includes/footer.php';
            ?>
        </div>
    </body>
</html>
