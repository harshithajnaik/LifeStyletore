<?php
include 'includes/common.php';
$user_id = $_SESSION['id'];
$item_id = $_GET['id'];
$qu = "INSERT INTO user_items(user_id, item_id, status) VALUES('$user_id', '$item_id', 'Added to cart')";
$fetch = mysqli_query($con, '$qu');
header('location:products_page.php');

?>
