
<?php 
include 'includes/common.php'
?>
<html>
    <head>
        <title>Log In to Life Style</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <link href ="bootstrap/css/bootstrap.min.css" rel = "stylesheet" type ="text/css">
        <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src= "bootstrap/js/jquery-3.2.1.min.js"></script>
        <link href ="css_assi2.css" type="text/css" rel="stylesheet">
    </head>
    <body>
      
       <?php
       include 'includes/header.php'; ?>
  <div class="row">
       <div class="col-sm-4 col-sm-offset-4">
        <div class="panel panel-primary">
            
            <div class="panel-body text-danger"><h3><u>Login to make a purchase</u></h3>
                <form class="form" method="post" action="login_submit.php">
                Enter Email:<br>
                <input class="form-control" type="email" placeholder="john@abc.com" name = "email"><br>
                Enter Password:
                <input type="password" class="form-control" placeholder="********" name="password"><br>
             </form>
             <div class="panel-footer">

                 <button class="btn btn-block btn-primary">Don't have an account?Register</button>
 
            </div>
            </div>
          </div>
        </div>
  </div>
     <div class="row">
    <?php
       include 'includes/footer.php'; ?>
            </div>
       
      </body>
</html>
